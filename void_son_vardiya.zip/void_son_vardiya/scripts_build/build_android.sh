#!/usr/bin/env bash
# VOID: SON VARDİYA — Android APK derleme betiği (Linux/macOS).
# Kullanım:  ./scripts_build/build_android.sh [debug|release]
# Gereksinimler: Godot 4.3 (GODOT=/yol/godot), JDK 17+, Android SDK (ANDROID_HOME),
#                Godot 4.3 export template'leri (editörden veya --install-templates ile).
set -euo pipefail
MODE="${1:-debug}"
GODOT="${GODOT:-godot}"
: "${ANDROID_HOME:?ANDROID_HOME tanımlı olmalı (Android SDK: build-tools;34.0.0, platforms;android-34, cmdline-tools;latest, platform-tools)}"
JAVA_HOME="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")}"
cd "$(dirname "$0")/.."
mkdir -p build

# Debug keystore (yoksa oluştur)
DEBUG_KS="${HOME}/.android/debug.keystore"
if [ ! -f "$DEBUG_KS" ]; then
  mkdir -p "${HOME}/.android"
  keytool -genkeypair -v -keystore "$DEBUG_KS" -storepass android -alias androiddebugkey \
    -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
fi

# Godot editör ayarları: SDK / JDK / keystore yolları
SETTINGS_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/godot"
mkdir -p "$SETTINGS_DIR"
cat > "$SETTINGS_DIR/editor_settings-4.3.tres" <<EOS
[gd_resource type="EditorSettings" format=3]

[resource]
export/android/android_sdk_path = "$ANDROID_HOME"
export/android/java_sdk_path = "$JAVA_HOME"
export/android/debug_keystore = "$DEBUG_KS"
export/android/debug_keystore_user = "androiddebugkey"
export/android/debug_keystore_pass = "android"
EOS

"$GODOT" --headless --path . --import || true

if [ "$MODE" = "release" ]; then
  : "${RELEASE_KEYSTORE:?RELEASE_KEYSTORE (keystore yolu) tanımlı olmalı}"
  : "${RELEASE_KEYSTORE_USER:?RELEASE_KEYSTORE_USER tanımlı olmalı}"
  : "${RELEASE_KEYSTORE_PASSWORD:?RELEASE_KEYSTORE_PASSWORD tanımlı olmalı}"
  export GODOT_ANDROID_KEYSTORE_RELEASE_PATH="$RELEASE_KEYSTORE"
  export GODOT_ANDROID_KEYSTORE_RELEASE_USER="$RELEASE_KEYSTORE_USER"
  export GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD="$RELEASE_KEYSTORE_PASSWORD"
  "$GODOT" --headless --path . --export-release "Android Release" build/void_son_vardiya_release.apk
  echo "APK: build/void_son_vardiya_release.apk"
else
  "$GODOT" --headless --path . --export-debug "Android Debug" build/void_son_vardiya_debug.apk
  echo "APK: build/void_son_vardiya_debug.apk"
fi
