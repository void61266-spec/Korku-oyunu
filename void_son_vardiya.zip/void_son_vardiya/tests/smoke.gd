extends Node
## Otomatik duman testi: godot --headless res://tests/smoke.tscn

var g: Node
var fails := 0


func check(cond: bool, msg: String) -> void:
	if cond:
		print("  OK   ", msg)
	else:
		print("  FAIL ", msg)
		fails += 1


func _ready() -> void:
	var packed: PackedScene = load("res://scenes/game.tscn")
	g = packed.instantiate()
	get_tree().root.add_child.call_deferred(g)
	await get_tree().create_timer(0.5).timeout
	for i in 6:
		await get_tree().physics_frame
	run()


func step(id: String) -> void:
	check(g.mission.current_id() == id, "adım = %s (şu an: %s)" % [id, g.mission.current_id()])


func point(id: String) -> void:
	g._on_point(g.market.points[id])


func pick(id: String) -> void:
	for p in g.market.pickups:
		if p.pickup_id == id:
			p.interact(g.player)
			return
	check(false, "pickup bulunamadı: " + id)


func run() -> void:
	print("== Dünya ==")
	var m = g.market
	check(m.doors.size() == 10, "kapı sayısı %d" % m.doors.size())
	check(m.pickups.size() > 10, "pickup sayısı %d" % m.pickups.size())
	check(m.hiding_spots.size() >= 7, "saklanma noktası %d" % m.hiding_spots.size())
	var edges := 0
	for i in g.creature.astar.get_point_count():
		edges += g.creature.astar.get_point_connections(i).size()
	print("  waypoint=%d bağlantı=%d" % [g.creature.astar.get_point_count(), edges / 2])
	check(g.creature.graph_ready, "yol grafı hazır")
	var a: Vector3 = Vector3(14, 0, 4)
	var targets := {"ana market->lab": Vector3(4, -5, 52), "lab->otopark": Vector3(14, 0, -7), "ana->tuvalet": Vector3(26, 0, 21.5),
		"ana->guvenlik": Vector3(31, 0, 3.5), "ana->ofis": Vector3(31, 0, 10.5), "ana->soguk": Vector3(10.5, 0, 21.5)}
	var cr: Creature = g.creature
	for k in targets:
		var s: int = cr.astar.get_closest_point(a)
		var e: int = cr.astar.get_closest_point(targets[k])
		var path := cr.astar.get_id_path(s, e)
		check(path.size() > 0, "yol var: " + k + " (%d düğüm)" % path.size())
	var lab_to_out := cr.astar.get_id_path(cr.astar.get_closest_point(Vector3(4, -5, 52)), cr.astar.get_closest_point(Vector3(14, 0, -7)))
	check(lab_to_out.size() > 0, "lab -> otopark yolu")

	print("== Hikâye ==")
	step("shelves")
	point("shelf1"); point("shelf2"); point("shelf3")
	step("register")
	point("register")
	check(g.player.inventory.has_item("ofis_anahtari"), "kasa ofis anahtarı verdi")
	step("frontdoor")
	point("frontdoor")
	step("key")
	pick("key_staff")
	step("depo")
	point("depo_check")
	step("power_check")
	point("panel")
	await get_tree().create_timer(0.1).timeout
	step("fuse_find")
	check(g.market.changes_applied, "kesinti sonrası market değişti")
	check(g.market.doors["personel"].jammed, "personel kapısı sıkıştı")
	pick("fuse")
	step("fuse_place")
	point("fusebox")
	step("generator")
	check(not g.player.inventory.has_item("sigorta"), "sigorta harcandı")
	point("generator")
	step("security")
	g._on_trigger("main_enter")
	check(g.slammed and g.market.doors["door_a"].locked, "kapı arkadan kilitlendi")
	g._on_trigger("security")
	step("cameras")
	g._on_cam_viewed(0); g._on_cam_viewed(1); g._on_cam_viewed(0); g._on_cam_viewed(2)
	step("hidden")
	g._on_cam_closed()
	await get_tree().create_timer(0.2).timeout
	check(not g.market.doors["hidden"].locked, "gizli kapı açıldı")
	check(not g.market.doors["door_a"].locked, "kapı A tekrar açık")
	g.market.doors["hidden"].interact(g.player)
	step("descend")
	g._on_trigger("descend")
	step("keycard")
	pick("keycard")
	step("terminal")
	point("terminal")
	step("cell")
	check(g.market.doors["cold"].locked, "soğuk depo kilitli")
	g.market.doors["cold"].interact(g.player)
	check(not g.market.doors["cold"].locked, "kart soğuk depoyu açtı")
	pick("cell")
	step("reactor")
	check(g.mission.current_id() == "reactor", "reactor adımı")
	print("== Kayıt ==")
	g._ready_done = true
	g._save()
	check(SaveSystem.has_save(), "kayıt dosyası yazıldı")
	var d: Dictionary = SaveSystem.read()
	check(int(d.mission.index) == g.mission.index, "kayıtta görev indeksi doğru")
	point("reactor")
	check(g.creature.rage, "final: yaratık öfkeli")
	step("escape")
	check(not g.market.doors["back"].locked, "arka kapı açıldı")
	g._on_trigger("escape")
	check(g.mission.finished, "oyun bitti")
	print("== Yaratık ==")
	g.game_over = false
	get_tree().paused = false
	g.creature.deactivate()
	g.creature.rage = false
	g.creature.allow_underground = true
	g.creature.activate(Vector3(14, 0, 4))
	g.player.global_position = Vector3(14, 0.1, 11)
	var moved := 0.0
	var start: Vector3 = g.creature.global_position
	for i in 240:
		await get_tree().physics_frame
		moved = maxf(moved, start.distance_to(g.creature.global_position))
	check(moved > 2.0, "yaratık devriye geziyor (%.1f m)" % moved)
	g.player.global_position = Vector3(4, -5, 50)
	g.creature._set_state(Creature.State.PATROL)
	g.creature.hear(Vector3(24, 0, 4), 100.0)
	check(g.creature.state == Creature.State.INVESTIGATE, "sese tepki verdi")
	print("== Sonuç: %d hata ==" % fails)
	SaveSystem.delete_save()
	get_tree().quit(fails)
