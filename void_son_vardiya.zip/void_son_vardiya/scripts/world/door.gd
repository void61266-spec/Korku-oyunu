class_name Door
extends Interactable
## Menteşeli kapı. Oyuncu için collision layer 2'dedir; yaratık kapıları aşar ve açar.

signal opened_changed(door: Door)

var door_id: String = ""
var width: float = 1.2
var height: float = 2.3
var locked: bool = false
var required_item: String = ""
var locked_message: String = "Kilitli."
var jammed: bool = false
var jam_message: String = "Kapı sıkışmış, açılmıyor."
var is_open: bool = false
var open_angle: float = -100.0   # derece
var thickness: float = 0.08
var skin: Material = null
var closed_prompt: String = "Kapıyı aç"
var open_prompt: String = "Kapıyı kapat"
var _tween: Tween


func _init() -> void:
	collision_layer = 2 | 4
	collision_mask = 0


func _ready() -> void:
	var mat: Material = skin
	if mat == null:
		mat = Props.tex_mat("door_wood", Color(0.34, 0.24, 0.16), 0.05, 5, 0, Color.BLACK, 0.7, 0.8)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(width, height, thickness)
	mi.mesh = bm
	mi.material_override = mat
	mi.position = Vector3(width * 0.5, height * 0.5, 0.0)
	add_child(mi)
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(width, height, maxf(0.14, thickness))
	cs.shape = shape
	cs.position = mi.position
	add_child(cs)
	# Kapı kolu
	var handle := MeshInstance3D.new()
	var hm := BoxMesh.new()
	hm.size = Vector3(0.12, 0.04, 0.14)
	handle.mesh = hm
	handle.material_override = Props.color_mat("door_handle", Color(0.7, 0.7, 0.72), 0.3)
	handle.position = Vector3(width - 0.14, 1.0, 0.0)
	add_child(handle)
	add_to_group("doors")


func get_prompt() -> String:
	if jammed:
		return "Sıkışmış"
	if locked:
		return "Kilitli"
	return open_prompt if is_open else closed_prompt


func _on_interact(player: Node) -> void:
	if jammed:
		player.message.emit(jam_message)
		AudioManager.play(&"locked")
		return
	if locked:
		if required_item != "" and player.inventory.has_item(required_item):
			locked = false
			AudioManager.play(&"click")
			var iname: String = String(Inventory.ITEMS.get(required_item, {}).get("name", required_item))
			player.message.emit("%s ile kilit açıldı." % iname)
		else:
			player.message.emit(locked_message)
			AudioManager.play(&"locked")
			return
	set_open(not is_open, true)


func set_open(value: bool, animate: bool) -> void:
	if value == is_open and animate:
		return
	is_open = value
	var target := deg_to_rad(open_angle) if is_open else 0.0
	if _tween and _tween.is_valid():
		_tween.kill()
	if animate:
		AudioManager.play(&"door", -4.0, randf_range(0.9, 1.1))
		_tween = create_tween()
		_tween.tween_property(self, "rotation:y", _base_yaw() + target, 0.6)\
			.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	else:
		rotation.y = _base_yaw() + target
	opened_changed.emit(self)


var base_yaw: float = 0.0


func _base_yaw() -> float:
	return base_yaw


## Yaratık / olay için: kilidi yok sayıp açar.
func force_open(animate: bool = true) -> void:
	locked = false
	jammed = false
	set_open(true, animate)


func force_close(lock_it: bool, animate: bool = true) -> void:
	set_open(false, animate)
	locked = lock_it
