class_name Props
extends RefCounted
## Prosedürel materyal ve prop üreticileri (harici asset gerektirmez).
## Collision katmanları: 1 = dünya, 2 = kapılar, 4 = etkileşim, 16 = oyuncu

static var _mats: Dictionary = {}

const PRODUCT_COLORS: Array[Color] = [
	Color(0.75, 0.15, 0.12), Color(0.9, 0.75, 0.15), Color(0.18, 0.45, 0.75),
	Color(0.2, 0.6, 0.3), Color(0.85, 0.85, 0.8), Color(0.55, 0.3, 0.15),
	Color(0.9, 0.45, 0.1), Color(0.5, 0.2, 0.5),
]


static func _make_tex(base: Color, amt: float, seed_: int, grid: int, grout: Color) -> ImageTexture:
	var size := 128
	var img := Image.create(size, size, false, Image.FORMAT_RGB8)
	var n := FastNoiseLite.new()
	n.seed = seed_
	n.frequency = 0.09
	for y in size:
		for x in size:
			var v: float = n.get_noise_2d(x, y) * amt
			var c := Color(base.r + v, base.g + v, base.b + v)
			if grid > 0:
				var cell: int = size / grid
				if x % cell < 2 or y % cell < 2:
					c = grout
			img.set_pixel(x, y, c)
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


static func tex_mat(key: String, base: Color, amt: float = 0.06, seed_: int = 1, grid: int = 0,
		grout: Color = Color(0.05, 0.05, 0.05), tile: float = 0.5, rough: float = 0.9) -> StandardMaterial3D:
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_texture = _make_tex(base, amt, seed_, grid, grout)
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3(tile, tile, tile)
	m.roughness = rough
	_mats[key] = m
	return m


static func color_mat(key: String, color: Color, rough: float = 0.8, emission: float = 0.0) -> StandardMaterial3D:
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	if emission > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = emission
	_mats[key] = m
	return m


static func box(parent: Node, center: Vector3, size: Vector3, material: Material,
		layer: int = 1, collide: bool = true) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = center
	body.collision_layer = layer if collide else 0
	body.collision_mask = 0
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = material
	body.add_child(mi)
	if collide:
		var cs := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		cs.shape = shape
		body.add_child(cs)
	parent.add_child(body)
	return body


static func cylinder(parent: Node, center: Vector3, radius: float, height: float,
		material: Material, collide: bool = true) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = center
	body.collision_layer = 1 if collide else 0
	body.collision_mask = 0
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = 12
	cm.rings = 1
	mi.mesh = cm
	mi.material_override = material
	body.add_child(mi)
	if collide:
		var cs := CollisionShape3D.new()
		var shape := CylinderShape3D.new()
		shape.radius = radius
		shape.height = height
		cs.shape = shape
		body.add_child(cs)
	parent.add_child(body)
	return body


## Çift taraflı market rafı. Uzunluk x ekseni boyunca; yaw ile döndürülür.
static func shelf(parent: Node, pos: Vector3, yaw: float, length: float, rng: RandomNumberGenerator) -> Node3D:
	var metal := color_mat("shelf_metal", Color(0.32, 0.34, 0.37), 0.5)
	var depth := 0.9
	var height := 2.0
	var root := StaticBody3D.new()
	root.position = pos
	root.rotation.y = yaw
	root.collision_layer = 1
	root.collision_mask = 0
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(length, height, depth)
	cs.shape = shape
	cs.position.y = height * 0.5
	root.add_child(cs)

	# İskelet: arka panel + 5 raf tablası.
	var back := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(length, height, 0.04)
	back.mesh = bm
	back.material_override = metal
	back.position.y = height * 0.5
	root.add_child(back)
	var levels := [0.12, 0.62, 1.12, 1.62, 1.98]
	for ly in levels:
		var plank := MeshInstance3D.new()
		var pm := BoxMesh.new()
		pm.size = Vector3(length, 0.04, depth)
		plank.mesh = pm
		plank.material_override = metal
		plank.position.y = ly
		root.add_child(plank)

	# Ürünler: tek MultiMesh (tek draw call).
	var per_row: int = int(length / 0.26)
	var count: int = 4 * per_row * 2
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	var prod := BoxMesh.new()
	prod.size = Vector3(0.2, 0.3, 0.2)
	mm.mesh = prod
	mm.instance_count = count
	var idx := 0
	for li in 4:
		var base_y: float = float(levels[li]) + 0.02 + 0.15
		for side in [-1, 1]:
			for i in per_row:
				var x: float = -length * 0.5 + 0.18 + i * 0.26
				var sc := Vector3(rng.randf_range(0.8, 1.15), rng.randf_range(0.7, 1.2), rng.randf_range(0.8, 1.1))
				var p := Vector3(x, base_y, float(side) * 0.22)
				mm.set_instance_transform(idx, Transform3D(Basis.from_scale(sc), p))
				mm.set_instance_color(idx, PRODUCT_COLORS[rng.randi() % PRODUCT_COLORS.size()])
				idx += 1
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	var pmat := StandardMaterial3D.new()
	pmat.vertex_color_use_as_albedo = true
	pmat.roughness = 0.6
	mmi.material_override = pmat
	root.add_child(mmi)
	parent.add_child(root)
	return root


static func make_label3d(text: String, pos: Vector3, size: float, color: Color) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.position = pos
	l.pixel_size = size
	l.modulate = color
	l.outline_size = 4
	l.no_depth_test = false
	return l
