class_name Interactable
extends StaticBody3D
## Oyuncunun etkileşime girebildiği her nesnenin tabanı (collision layer 4).

@export var prompt: String = "İncele"
var enabled: bool = true


func _init() -> void:
	collision_layer = 4
	collision_mask = 0


func get_prompt() -> String:
	return prompt


func interact(player: Node) -> void:
	if enabled:
		_on_interact(player)


func _on_interact(_player: Node) -> void:
	pass


func set_active(active: bool) -> void:
	enabled = active
	visible = active
	collision_layer = 4 if active else 0
