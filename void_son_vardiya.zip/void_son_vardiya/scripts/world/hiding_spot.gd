class_name HidingSpot
extends Interactable
## Saklanma noktası (dolap, masa altı, kasa arkası, depo rafı).

var hide_position: Vector3 = Vector3.ZERO   # Oyuncunun saklanırken bulunduğu nokta
var exit_position: Vector3 = Vector3.ZERO   # Çıkış noktası
var look_yaw: float = 0.0
var hit_size: Vector3 = Vector3(0.9, 1.8, 0.9)
var checked_this_search: bool = false


func _ready() -> void:
	prompt = "Saklan"
	add_to_group("hiding_spots")
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = hit_size
	cs.shape = shape
	add_child(cs)


func _on_interact(player: Node) -> void:
	player.enter_hide(self)
