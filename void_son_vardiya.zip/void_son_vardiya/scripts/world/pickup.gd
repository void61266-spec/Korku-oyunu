class_name Pickup
extends Interactable
## Toplanabilir eşya.

signal collected(pickup: Pickup)

var pickup_id: String = ""
var item_id: String = ""
var amount: int = 1
var available_from: String = ""   # Bu görev adımına gelinene kadar görünmez.
var taken: bool = false
var _mesh: MeshInstance3D


func _ready() -> void:
	var data: Dictionary = Inventory.ITEMS.get(item_id, {})
	prompt = "Al: %s" % String(data.get("name", item_id))
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(0.5, 0.4, 0.5)
	cs.shape = shape
	add_child(cs)
	_mesh = MeshInstance3D.new()
	var bm := BoxMesh.new()
	var col := Color.WHITE
	match String(data.get("type", "")):
		"key":
			bm.size = Vector3(0.14, 0.03, 0.06)
			col = Color(0.9, 0.75, 0.2)
		"battery":
			bm.size = Vector3(0.06, 0.06, 0.16)
			col = Color(0.2, 0.8, 0.3)
		"note":
			bm.size = Vector3(0.2, 0.01, 0.28)
			col = Color(0.9, 0.88, 0.75)
		"card":
			bm.size = Vector3(0.14, 0.01, 0.09)
			col = Color(0.3, 0.6, 0.95)
		"special":
			bm.size = Vector3(0.18, 0.18, 0.18)
			col = Color(0.3, 0.9, 1.0)
		_:
			bm.size = Vector3(0.1, 0.1, 0.1)
			col = Color(0.9, 0.5, 0.2)
	_mesh.mesh = bm
	_mesh.material_override = Props.color_mat("pickup_" + String(data.get("type", "x")), col, 0.4, 0.6)
	_mesh.position.y = -0.1
	add_child(_mesh)
	if String(data.get("type", "")) != "note":
		var glow := OmniLight3D.new()
		glow.light_color = col
		glow.light_energy = 0.25
		glow.omni_range = 1.4
		glow.position.y = 0.1
		add_child(glow)


func _on_interact(player: Node) -> void:
	if taken:
		return
	taken = true
	AudioManager.play(&"pickup")
	collected.emit(self)
	set_active(false)


func apply_state() -> void:
	## Alınmışsa veya henüz erişilemezse gizler.
	pass
