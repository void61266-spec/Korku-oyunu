class_name SettingsMenu
extends CanvasLayer
## Ayarlar ekranı (ana menüden ve duraklatma menüsünden kullanılır).

signal closed


func _init() -> void:
	layer = 50
	process_mode = Node.PROCESS_MODE_ALWAYS


func _ready() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.88)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UIStyle.panel()
	panel.custom_minimum_size = Vector2(820, 0)
	center.add_child(panel)
	var outer := VBoxContainer.new()
	outer.add_theme_constant_override("separation", 8)
	panel.add_child(outer)
	outer.add_child(UIStyle.label("AYARLAR", 36, Color(0.85, 0.15, 0.1)))
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 360)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(scroll)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 10)
	scroll.add_child(v)

	_option(v, "Grafik kalitesi", ["Düşük", "Orta", "Yüksek"], Settings.graphics_quality,
		func(i: int) -> void: Settings.graphics_quality = i)
	_option(v, "FPS sınırı", ["30", "45", "60"], [30, 45, 60].find(Settings.fps_limit) if [30, 45, 60].has(Settings.fps_limit) else 2,
		func(i: int) -> void: Settings.fps_limit = [30, 45, 60][i])
	_slider(v, "Ses seviyesi", 0.0, 1.0, Settings.master_volume, func(x: float) -> void: Settings.master_volume = x)
	_slider(v, "Müzik seviyesi", 0.0, 1.0, Settings.music_volume, func(x: float) -> void: Settings.music_volume = x)
	_slider(v, "Efekt seviyesi", 0.0, 1.0, Settings.sfx_volume, func(x: float) -> void: Settings.sfx_volume = x)
	_slider(v, "Hassasiyet", 0.3, 3.0, Settings.sensitivity, func(x: float) -> void: Settings.sensitivity = x)
	_slider(v, "Buton boyutu", 0.6, 1.6, Settings.control_scale, func(x: float) -> void: Settings.control_scale = x)
	_check(v, "Titreşim", Settings.vibration, func(b: bool) -> void: Settings.vibration = b)
	_check(v, "Kontrol düzeni: ters (joystick sağda)", Settings.swap_hands, func(b: bool) -> void: Settings.swap_hands = b)

	var back := Button.new()
	back.text = "GERİ"
	UIStyle.style_button(back, 28, true)
	back.pressed.connect(_on_back)
	outer.add_child(back)


func _row(parent: Control, text: String) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	var l := UIStyle.label(text, 22)
	l.custom_minimum_size = Vector2(300, 0)
	h.add_child(l)
	parent.add_child(h)
	return h


func _option(parent: Control, text: String, items: Array, selected: int, cb: Callable) -> void:
	var h := _row(parent, text)
	var o := OptionButton.new()
	for it in items:
		o.add_item(String(it))
	o.selected = clampi(selected, 0, items.size() - 1)
	o.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	UIStyle.style_button(o, 22)
	o.item_selected.connect(func(i: int) -> void:
		cb.call(i)
		Settings.apply())
	h.add_child(o)


func _slider(parent: Control, text: String, mn: float, mx: float, val: float, cb: Callable) -> void:
	var h := _row(parent, text)
	var s := HSlider.new()
	s.min_value = mn
	s.max_value = mx
	s.step = 0.05
	s.value = val
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.custom_minimum_size = Vector2(0, 40)
	s.value_changed.connect(func(x: float) -> void:
		cb.call(x)
		Settings.apply())
	h.add_child(s)


func _check(parent: Control, text: String, val: bool, cb: Callable) -> void:
	var c := CheckButton.new()
	c.text = text
	c.button_pressed = val
	c.add_theme_font_size_override("font_size", 22)
	c.toggled.connect(func(b: bool) -> void:
		cb.call(b)
		Settings.apply())
	parent.add_child(c)


func _on_back() -> void:
	Settings.save_settings()
	closed.emit()
	queue_free()
