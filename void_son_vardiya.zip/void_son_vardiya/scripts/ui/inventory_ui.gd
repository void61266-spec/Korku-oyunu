class_name InventoryUI
extends CanvasLayer
## Dokunmatik uyumlu envanter paneli.

signal closed
signal read_requested(item_id: String)
signal battery_requested

var _inv: Inventory
var _list: VBoxContainer
var _desc: Label
var _root: Control


func _init() -> void:
	layer = 20
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false


func _ready() -> void:
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(_root)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.7)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.add_child(center)
	var panel := UIStyle.panel()
	panel.custom_minimum_size = Vector2(760, 0)
	center.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	panel.add_child(v)
	v.add_child(UIStyle.label("ENVANTER", 36, Color(0.85, 0.15, 0.1)))
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 300)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(scroll)
	_list = VBoxContainer.new()
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_theme_constant_override("separation", 8)
	scroll.add_child(_list)
	_desc = UIStyle.label("", 20, Color(0.8, 0.8, 0.75))
	_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_desc.custom_minimum_size = Vector2(0, 50)
	v.add_child(_desc)
	var close := Button.new()
	close.text = "KAPAT"
	UIStyle.style_button(close, 28, true)
	close.pressed.connect(close_panel)
	v.add_child(close)


func open_panel(inv: Inventory) -> void:
	_inv = inv
	_refresh()
	visible = true


func close_panel() -> void:
	visible = false
	closed.emit()


func refresh() -> void:
	if visible and _inv != null:
		_refresh()


func _refresh() -> void:
	for c in _list.get_children():
		c.queue_free()
	_desc.text = ""
	if _inv.items.is_empty():
		_list.add_child(UIStyle.label("Envanterin boş.", 24, Color(0.6, 0.6, 0.6)))
		return
	for id in _inv.items:
		var def: Dictionary = Inventory.ITEMS.get(id, {})
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		var count: int = int(_inv.items[id])
		var name_text: String = String(def.get("name", id))
		if count > 1:
			name_text += "  x%d" % count
		var info := Button.new()
		info.text = "%s  [%s]" % [name_text, _type_label(String(def.get("type", "")))]
		info.alignment = HORIZONTAL_ALIGNMENT_LEFT
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		UIStyle.style_button(info, 22)
		var desc_text: String = String(def.get("desc", ""))
		info.pressed.connect(func() -> void: _desc.text = desc_text)
		row.add_child(info)
		var t := String(def.get("type", ""))
		if t == "note":
			var b := Button.new()
			b.text = "OKU"
			UIStyle.style_button(b, 22, true)
			b.pressed.connect(func() -> void: read_requested.emit(id))
			row.add_child(b)
		elif t == "battery":
			var b2 := Button.new()
			b2.text = "KULLAN"
			UIStyle.style_button(b2, 22, true)
			b2.pressed.connect(func() -> void: battery_requested.emit())
			row.add_child(b2)
		_list.add_child(row)


func _type_label(t: String) -> String:
	match t:
		"key": return "Anahtar"
		"item": return "Eşya"
		"battery": return "Pil"
		"note": return "Not"
		"card": return "Kart"
		"special": return "Özel eşya"
	return "Eşya"
