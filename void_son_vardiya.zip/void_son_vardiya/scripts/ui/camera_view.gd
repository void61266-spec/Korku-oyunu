class_name CameraView
extends CanvasLayer
## Güvenlik monitörü: gerçek 3D sahneyi SubViewport içindeki kameralardan gösterir.

signal cam_viewed(index: int)
signal closed

var _cams: Array = []
var _index := 0
var _sv: SubViewport
var _cam: Camera3D
var _tex: TextureRect
var _title: Label
var _noise: Control
var _t := 0.0


func _init() -> void:
	layer = 22
	visible = false


func _ready() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.92)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	_sv = SubViewport.new()
	_sv.size = Vector2i(512, 288)
	_sv.render_target_update_mode = SubViewport.UPDATE_DISABLED
	_sv.msaa_3d = Viewport.MSAA_DISABLED
	_sv.world_3d = get_viewport().find_world_3d()
	add_child(_sv)
	_cam = Camera3D.new()
	_cam.fov = 80.0
	_cam.far = 40.0
	_sv.add_child(_cam)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	center.add_child(v)
	_title = UIStyle.label("", 28, Color(0.4, 1.0, 0.5))
	v.add_child(_title)
	_tex = TextureRect.new()
	_tex.texture = _sv.get_texture()
	_tex.custom_minimum_size = Vector2(800, 450)
	_tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_tex.stretch_mode = TextureRect.STRETCH_SCALE
	_tex.modulate = Color(0.65, 1.0, 0.75)
	v.add_child(_tex)
	_noise = Control.new()
	_noise.set_anchors_preset(Control.PRESET_FULL_RECT)
	_noise.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_noise.draw.connect(_draw_noise)
	_tex.add_child(_noise)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	v.add_child(row)
	var prev := Button.new()
	prev.text = "◄"
	UIStyle.style_button(prev, 28, true)
	prev.pressed.connect(func() -> void: _show((_index - 1 + _cams.size()) % _cams.size()))
	row.add_child(prev)
	var close := Button.new()
	close.text = "KAPAT"
	UIStyle.style_button(close, 28, true)
	close.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	close.pressed.connect(close_panel)
	row.add_child(close)
	var next := Button.new()
	next.text = "►"
	UIStyle.style_button(next, 28, true)
	next.pressed.connect(func() -> void: _show((_index + 1) % _cams.size()))
	row.add_child(next)


func open_panel(cams: Array) -> void:
	_cams = cams
	visible = true
	_sv.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	_show(0)


func close_panel() -> void:
	visible = false
	_sv.render_target_update_mode = SubViewport.UPDATE_DISABLED
	closed.emit()


func current_index() -> int:
	return _index


func _show(i: int) -> void:
	_index = i
	var c: Dictionary = _cams[i]
	_cam.global_position = c.pos
	_cam.look_at(c.look, Vector3.UP)
	_title.text = "● %s" % String(c.name)
	AudioManager.play(&"click", -6.0, 0.6)
	cam_viewed.emit(i)


func _process(delta: float) -> void:
	if visible:
		_t += delta
		_noise.queue_redraw()


func _draw_noise() -> void:
	var s := _noise.size
	var y := fmod(_t * 60.0, 6.0)
	while y < s.y:
		_noise.draw_line(Vector2(0, y), Vector2(s.x, y), Color(0, 0, 0, 0.25), 1.0)
		y += 4.0
	for i in 40:
		var p := Vector2(randf() * s.x, randf() * s.y)
		_noise.draw_rect(Rect2(p, Vector2(randf_range(4, 30), 1.5)), Color(1, 1, 1, randf() * 0.18))
