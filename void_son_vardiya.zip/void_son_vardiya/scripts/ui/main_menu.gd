extends Node3D
## Ana menü: karanlık market koridoru arka planı + menü butonları.

var _cam: Camera3D
var _t := 0.0
var _ui_root: Control
var _box: VBoxContainer
var _lights: Array[FlickerLight] = []


func _ready() -> void:
	AudioManager.start_ambient()
	_build_backdrop()
	_build_ui()
	_show_main()


func _build_backdrop() -> void:
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color.BLACK
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.08, 0.09, 0.12)
	env.ambient_light_energy = 0.5
	env.fog_enabled = true
	env.fog_light_color = Color(0.04, 0.045, 0.05)
	env.fog_density = 0.05
	we.environment = env
	add_child(we)
	var floor_mat := Props.tex_mat("floor_tile", Color(0.62, 0.62, 0.58), 0.05, 2, 4, Color(0.28, 0.28, 0.27), 0.5, 0.55)
	var wall_mat := Props.tex_mat("wall", Color(0.58, 0.6, 0.55), 0.07, 3, 0, Color.BLACK, 0.4)
	Props.box(self, Vector3(0, -0.1, 0), Vector3(9, 0.2, 60), floor_mat, 1, false)
	Props.box(self, Vector3(0, 3.1, 0), Vector3(9, 0.2, 60), wall_mat, 1, false)
	Props.box(self, Vector3(-4.5, 1.5, 0), Vector3(0.2, 3, 60), wall_mat, 1, false)
	Props.box(self, Vector3(4.5, 1.5, 0), Vector3(0.2, 3, 60), wall_mat, 1, false)
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	for i in 8:
		var z := 8.0 - i * 4.8
		Props.shelf(self, Vector3(-2.6, 0, z), PI * 0.5, 4.4, rng)
		Props.shelf(self, Vector3(2.6, 0, z), PI * 0.5, 4.4, rng)
	for i in 5:
		var l := FlickerLight.new()
		l.position = Vector3(0, 2.75, 6.0 - i * 9.0)
		l.base_energy = 1.0
		l.omni_range = 11.0
		l.mode = 2 if i == 1 else (1 if i % 2 == 0 else 0)
		add_child(l)
		_lights.append(l)
	_cam = Camera3D.new()
	_cam.position = Vector3(0, 1.55, 10)
	_cam.fov = 70.0
	add_child(_cam)
	_cam.current = true


func _process(delta: float) -> void:
	_t += delta
	var z := 10.0 - fmod(_t * 0.5, 30.0)
	_cam.position = Vector3(sin(_t * 0.2) * 0.4, 1.55 + sin(_t * 0.9) * 0.02, z)
	_cam.rotation = Vector3(sin(_t * 0.31) * 0.02, sin(_t * 0.17) * 0.06, 0.0)


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	_ui_root = Control.new()
	_ui_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(_ui_root)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.35)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui_root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	_ui_root.add_child(center)
	_box = VBoxContainer.new()
	_box.custom_minimum_size = Vector2(520, 0)
	_box.add_theme_constant_override("separation", 14)
	center.add_child(_box)


func _clear() -> void:
	for c in _box.get_children():
		c.queue_free()


func _title() -> void:
	var t := UIStyle.label("VOID", 110, Color(0.85, 0.1, 0.08))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_box.add_child(t)
	var s := UIStyle.label("SON VARDİYA", 44, Color(0.9, 0.9, 0.85))
	s.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_box.add_child(s)
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 14)
	_box.add_child(gap)


func _btn(text: String, cb: Callable, accent: bool = true) -> Button:
	var b := Button.new()
	b.text = text
	UIStyle.style_button(b, 30, accent)
	b.pressed.connect(func() -> void:
		AudioManager.play(&"click", -4.0)
		cb.call())
	_box.add_child(b)
	return b


func _show_main() -> void:
	_clear()
	_title()
	_btn("TEK OYUNCULU", _show_single)
	_btn("ÇOK OYUNCULU", _show_multi)
	_btn("AYARLAR", func() -> void: add_child(SettingsMenu.new()), false)
	_btn("ÇIKIŞ", func() -> void: get_tree().quit(), false)


func _show_single() -> void:
	_clear()
	_title()
	var cont := _btn("DEVAM ET", func() -> void: GameManager.start_single(true))
	cont.disabled = not SaveSystem.has_save()
	_btn("YENİ OYUN", func() -> void: GameManager.start_single(false))
	_btn("GERİ", _show_main, false)


func _show_multi() -> void:
	_clear()
	_title()
	var info := UIStyle.label("Çok oyunculu mod internet bağlantısı gerektirir.\nBu sürümde henüz etkin değil; tek oyunculu mod tamamen çevrimdışı çalışır.", 22, Color(0.85, 0.8, 0.6))
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_box.add_child(info)
	var b1 := _btn("ODA OLUŞTUR", func() -> void: pass)
	b1.disabled = true
	var b2 := _btn("ODAYA KATIL", func() -> void: pass)
	b2.disabled = true
	_btn("GERİ", _show_main, false)
