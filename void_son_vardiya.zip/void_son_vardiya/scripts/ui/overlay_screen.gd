class_name OverlayScreen
extends CanvasLayer
## Duraklatma / ölüm / bitiş ekranı: başlık + alt başlık + butonlar.

var _box: VBoxContainer


func _init() -> void:
	layer = 40
	process_mode = Node.PROCESS_MODE_ALWAYS


func setup(title: String, subtitle: String, buttons: Array, title_color: Color = Color(0.85, 0.15, 0.1)) -> void:
	var bg := ColorRect.new()
	bg.color = Color(0, 0, 0, 0.8)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	_box = VBoxContainer.new()
	_box.custom_minimum_size = Vector2(520, 0)
	_box.add_theme_constant_override("separation", 14)
	center.add_child(_box)
	var t := UIStyle.label(title, 56, title_color)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_box.add_child(t)
	if subtitle != "":
		var s := UIStyle.label(subtitle, 24)
		s.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		s.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_box.add_child(s)
	for b in buttons:
		var btn := Button.new()
		btn.text = String(b.text)
		UIStyle.style_button(btn, 28, true)
		btn.pressed.connect(b.call)
		_box.add_child(btn)
