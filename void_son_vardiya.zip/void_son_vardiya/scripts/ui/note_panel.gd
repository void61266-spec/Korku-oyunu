class_name NotePanel
extends CanvasLayer
## Not / terminal metni okuma paneli.

signal closed

var _title: Label
var _body: Label


func _init() -> void:
	layer = 25
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false


func _ready() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.75)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UIStyle.panel()
	panel.custom_minimum_size = Vector2(780, 0)
	center.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	panel.add_child(v)
	_title = UIStyle.label("", 34, Color(0.85, 0.15, 0.1))
	v.add_child(_title)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 280)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(scroll)
	_body = UIStyle.label("", 22, Color(0.92, 0.9, 0.8))
	_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_body.custom_minimum_size = Vector2(700, 0)
	scroll.add_child(_body)
	var b := Button.new()
	b.text = "KAPAT"
	UIStyle.style_button(b, 28, true)
	b.pressed.connect(close_panel)
	v.add_child(b)


func open_panel(title: String, text: String) -> void:
	_title.text = title
	_body.text = text
	visible = true


func close_panel() -> void:
	visible = false
	closed.emit()
