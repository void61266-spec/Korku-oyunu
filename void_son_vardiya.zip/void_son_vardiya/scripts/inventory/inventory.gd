class_name Inventory
extends RefCounted
## Basit envanter: eşya kimliği -> adet.

signal changed

const ITEMS: Dictionary = {
	"personel_anahtari": {"name": "Personel Anahtarı", "type": "key", "stack": false,
		"desc": "Elektrik ve güvenlik odası kapılarını açar."},
	"ofis_anahtari": {"name": "Ofis Anahtarı", "type": "key", "stack": false,
		"desc": "Müdür ofisinin anahtarı."},
	"sigorta": {"name": "Sigorta", "type": "item", "stack": false,
		"desc": "Yanık sigortanın yerine takılacak ana sigorta."},
	"pil": {"name": "Pil", "type": "battery", "stack": true,
		"desc": "El fenerinin pilini doldurur."},
	"erisim_karti": {"name": "Erişim Kartı", "type": "card", "stack": false,
		"desc": "Üzerinde 'VOID / Seviye 3' yazıyor."},
	"kaynak_hucresi": {"name": "Kaynak Hücresi", "type": "special", "stack": false,
		"desc": "Soğuk, hafifçe titreyen mavi bir silindir."},
	"not_vardiya": {"name": "Not: Vardiya Listesi", "type": "note", "stack": false,
		"title": "Vardiya Listesi",
		"text": "GECE VARDİYASI\n\nRaflar, kasa, ön kapı, depo, elektrik panosu.\nHer şeyi kontrol et, sabaha kadar kimseyi içeri alma.\n\nNot: Depoda gece ses olursa merak etme. Eski borular. Sadece merak etme.\n\n— Müdür Selim"},
	"not_ofis": {"name": "Not: Müdürün Notu", "type": "note", "stack": false,
		"title": "Müdürün Notu",
		"text": "Depo arka duvarı için hâlâ izin çıkmadı. Şirket 'rutin tadilat' diyor ama\ngece yarısı sonrası duvarın ardından metal sesleri geliyor.\n\nKamera 2'yi ve 3'ü izlemeyi bırakma. Bir şey hareket ederse gözünü ayırma."},
	"not_tuvalet": {"name": "Not: Karalanmış Kâğıt", "type": "note", "stack": false,
		"title": "Karalanmış Kâğıt",
		"text": "O BURADA\n\nO BURADA\n\nIşıkları kapatma ama ışık da onu durdurmuyor.\nSaklanırsan sessiz ol. Kalp atışını bile duyuyor."},
	"not_lab": {"name": "Not: Deney Günlüğü", "type": "note", "stack": false,
		"title": "Deney Günlüğü",
		"text": "Denek 7 artık komutlara yanıt vermiyor.\nBeslenmesi için üstteki mağazadan gece vardiyası personeli getiriliyor.\n\nKaynak Hücresi ısındıkça uyanıyor. Soğuk hava deposunda tutmalıyız.\n\nEğer bunu okuyorsan: hücreyi reaktöre geri koy. Hepsi bitsin."},
}

var items: Dictionary = {}


func add(item_id: String, count: int = 1) -> void:
	var def: Dictionary = ITEMS.get(item_id, {})
	if not bool(def.get("stack", false)):
		items[item_id] = 1
	else:
		items[item_id] = int(items.get(item_id, 0)) + count
	changed.emit()


func has_item(item_id: String) -> bool:
	return int(items.get(item_id, 0)) > 0


func count_of(item_id: String) -> int:
	return int(items.get(item_id, 0))


func remove(item_id: String, count: int = 1) -> bool:
	if count_of(item_id) < count:
		return false
	items[item_id] = count_of(item_id) - count
	if int(items[item_id]) <= 0:
		items.erase(item_id)
	changed.emit()
	return true


func to_dict() -> Dictionary:
	return items.duplicate()


func from_dict(d: Dictionary) -> void:
	items.clear()
	for k in d:
		items[String(k)] = int(d[k])
	changed.emit()
