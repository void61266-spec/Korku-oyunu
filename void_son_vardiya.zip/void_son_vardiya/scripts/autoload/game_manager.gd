extends Node
## Oyun durumu ve sahne geçişleri. Autoload: "GameManager"

signal save_requested
signal pickup_collected(pickup_id: String)

enum Mode { SINGLE, MULTI }

const MENU_SCENE := "res://scenes/main_menu.tscn"
const GAME_SCENE := "res://scenes/game.tscn"

var mode: Mode = Mode.SINGLE
var continue_save: bool = false


func start_single(continue_game: bool) -> void:
	mode = Mode.SINGLE
	continue_save = continue_game and SaveSystem.has_save()
	if not continue_save:
		SaveSystem.delete_save()
	get_tree().paused = false
	get_tree().change_scene_to_file(GAME_SCENE)


func go_to_menu() -> void:
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().change_scene_to_file(MENU_SCENE)


func _notification(what: int) -> void:
	# Uygulama arka plana atılırken veya kapanırken ilerlemeyi kaydet.
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_requested.emit()
