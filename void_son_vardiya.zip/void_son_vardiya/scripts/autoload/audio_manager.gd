extends Node
## Prosedürel ses sistemi. Ses dosyası gerektirmez; sesler kodla üretilir.
## Autoload: "AudioManager"

const MIX_RATE := 22050
const POOL_SIZE := 6

var _streams: Dictionary = {}
var _ambient: AudioStreamPlayer
var _pool: Array[AudioStreamPlayer] = []
var _pool_index := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_streams[&"hum"] = _make_hum()
	_streams[&"step"] = _make_step()
	_streams[&"click"] = _make_click()
	_streams[&"pickup"] = _make_pickup()
	_streams[&"door"] = _make_door()
	_streams[&"locked"] = _make_locked()
	_streams[&"growl"] = _make_growl()
	_streams[&"scare"] = _make_scare()
	_streams[&"thump"] = _make_thump()
	_streams[&"clang"] = _make_clang()

	_ambient = AudioStreamPlayer.new()
	_ambient.bus = "Music"
	_ambient.stream = _streams[&"hum"]
	_ambient.volume_db = -14.0
	add_child(_ambient)

	for i in POOL_SIZE:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_pool.append(p)


func get_stream(sound: StringName) -> AudioStream:
	return _streams.get(sound)


func start_ambient() -> void:
	if not _ambient.playing:
		_ambient.play()


func stop_ambient() -> void:
	_ambient.stop()


func play(sound: StringName, volume_db: float = 0.0, pitch: float = 1.0) -> void:
	if not _streams.has(sound):
		return
	var p := _pool[_pool_index]
	_pool_index = (_pool_index + 1) % POOL_SIZE
	p.stream = _streams[sound]
	p.volume_db = volume_db
	p.pitch_scale = pitch
	p.play()


# --- Ses üretimi -----------------------------------------------------------

func _to_wav(samples: PackedFloat32Array, loop: bool) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(samples.size() * 2)
	for i in samples.size():
		bytes.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32767.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = MIX_RATE
	wav.stereo = false
	wav.data = bytes
	if loop:
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_begin = 0
		wav.loop_end = samples.size()
	return wav


func _make_hum() -> AudioStreamWAV:
	# 3 saniyelik kusursuz döngü: elektrik uğultusu + buzdolabı gürültüsü.
	var n := MIX_RATE * 3
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t := float(i) / MIX_RATE
		var v := 0.22 * sin(TAU * 50.0 * t)
		v += 0.10 * sin(TAU * 100.0 * t + 0.6)
		v += 0.05 * sin(TAU * 150.0 * t + 1.3)
		v += 0.03 * sin(TAU * 31.0 * t)
		v *= 0.85 + 0.15 * sin(TAU * (2.0 / 3.0) * t)
		s[i] = v
	return _to_wav(s, true)


func _make_step() -> AudioStreamWAV:
	var n := int(MIX_RATE * 0.2)
	var s := PackedFloat32Array()
	s.resize(n)
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	var prev := 0.0
	for i in n:
		var t := float(i) / MIX_RATE
		prev = prev * 0.82 + rng.randf_range(-1.0, 1.0) * 0.18
		s[i] = prev * exp(-t * 26.0) * 2.4
	return _to_wav(s, false)


func _make_click() -> AudioStreamWAV:
	var n := int(MIX_RATE * 0.07)
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t := float(i) / MIX_RATE
		s[i] = sin(TAU * 1100.0 * t) * exp(-t * 60.0) * 0.6
	return _to_wav(s, false)


func _make_pickup() -> AudioStreamWAV:
	var n := int(MIX_RATE * 0.25)
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t := float(i) / MIX_RATE
		var f := 660.0 if t < 0.1 else 990.0
		s[i] = sin(TAU * f * t) * exp(-t * 9.0) * 0.45
	return _to_wav(s, false)


func _make_door() -> AudioStreamWAV:
	# Gıcırtı: yavaşça düşen testere dişi + gürültü.
	var n := int(MIX_RATE * 0.7)
	var s := PackedFloat32Array()
	s.resize(n)
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	var phase := 0.0
	for i in n:
		var t := float(i) / MIX_RATE
		var f := lerpf(210.0, 120.0, t / 0.7) + 14.0 * sin(TAU * 7.0 * t)
		phase = fmod(phase + f / MIX_RATE, 1.0)
		var saw := phase * 2.0 - 1.0
		var env := sin(PI * clampf(t / 0.7, 0.0, 1.0))
		s[i] = (saw * 0.28 + rng.randf_range(-0.08, 0.08)) * env
	return _to_wav(s, false)


func _make_locked() -> AudioStreamWAV:
	var n := int(MIX_RATE * 0.18)
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t := float(i) / MIX_RATE
		s[i] = sin(TAU * 85.0 * t) * exp(-t * 22.0) * 0.8
	return _to_wav(s, false)


func _make_growl() -> AudioStreamWAV:
	var n := int(MIX_RATE * 1.3)
	var s := PackedFloat32Array()
	s.resize(n)
	var rng := RandomNumberGenerator.new()
	rng.seed = 21
	var phase := 0.0
	for i in n:
		var t := float(i) / MIX_RATE
		var f := 62.0 + 18.0 * sin(TAU * 5.5 * t) + 20.0 * t
		phase = fmod(phase + f / MIX_RATE, 1.0)
		var env := sin(PI * clampf(t / 1.3, 0.0, 1.0))
		s[i] = ((phase * 2.0 - 1.0) * 0.5 + rng.randf_range(-0.25, 0.25)) * env * 0.8
	return _to_wav(s, false)


func _make_scare() -> AudioStreamWAV:
	var n := int(MIX_RATE * 1.1)
	var s := PackedFloat32Array()
	s.resize(n)
	var rng := RandomNumberGenerator.new()
	rng.seed = 33
	var phase := 0.0
	for i in n:
		var t := float(i) / MIX_RATE
		var f := lerpf(900.0, 140.0, minf(t / 0.9, 1.0))
		phase = fmod(phase + f / MIX_RATE, 1.0)
		var env := exp(-t * 3.2)
		s[i] = ((phase * 2.0 - 1.0) * 0.45 + rng.randf_range(-0.6, 0.6)) * env
	return _to_wav(s, false)


func _make_thump() -> AudioStreamWAV:
	var n := int(MIX_RATE * 0.25)
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t := float(i) / MIX_RATE
		s[i] = sin(TAU * 52.0 * t) * exp(-t * 18.0) * 0.95
	return _to_wav(s, false)


func _make_clang() -> AudioStreamWAV:
	var n := int(MIX_RATE * 1.2)
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t := float(i) / MIX_RATE
		var v := sin(TAU * 420.0 * t) + 0.6 * sin(TAU * 913.0 * t) + 0.4 * sin(TAU * 1370.0 * t)
		s[i] = v * exp(-t * 4.5) * 0.28
	return _to_wav(s, false)
