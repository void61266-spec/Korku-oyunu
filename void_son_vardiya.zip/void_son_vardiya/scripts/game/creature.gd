class_name Creature
extends CharacterBody3D
## Yaratık yapay zekâsı: devriye, ses/görüş algısı, kovalama, arama, kaybetme.
## Yol bulma: MarketBuilder waypoint'lerinden çalışma anında kurulan AStar3D grafı.

signal caught
signal state_changed(new_state: int)

enum State { DORMANT, PATROL, INVESTIGATE, CHASE, SEARCH }

const PATROL_SPEED := 1.9
const INVESTIGATE_SPEED := 2.8
const SEARCH_SPEED := 2.4
const GRAVITY := 18.0

var chase_speed := 4.5
var state: State = State.DORMANT
var active := false                 # Hikâye yaratığı serbest bıraktı mı?
var allow_underground := false
var allow_outdoors := false
var rage := false                   # Final: dinlenme yok, daha hızlı

var player: Player
var builder: MarketBuilder
var astar := AStar3D.new()
var graph_ready := false

var _path: Array[Vector3] = []
var _path_i := 0
var _repath_t := 0.0
var _perceive_t := 0.0
var _last_known := Vector3.ZERO
var _lost_t := 0.0
var _wait_t := 0.0
var _lull_t := 0.0
var _investigate_pos := Vector3.ZERO
var _search_spots: Array[HidingSpot] = []
var _search_t := 0.0
var _known_spot: HidingSpot = null
var _last_seen_time := -100.0
var _step_dist := 0.0
var _door_t := 0.0
var _voice: AudioStreamPlayer3D
var _steps: AudioStreamPlayer3D
var _growl_t := 0.0
var _vis: Node3D


func _ready() -> void:
	collision_layer = 0
	collision_mask = 1
	add_to_group("creature")
	_build_visual()
	_voice = AudioStreamPlayer3D.new()
	_voice.bus = "SFX"
	_voice.unit_size = 6.0
	_voice.max_distance = 40.0
	add_child(_voice)
	_steps = AudioStreamPlayer3D.new()
	_steps.bus = "SFX"
	_steps.unit_size = 5.0
	_steps.max_distance = 30.0
	_steps.stream = AudioManager.get_stream(&"step")
	_steps.volume_db = 4.0
	add_child(_steps)
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 2.0
	cs.shape = cap
	cs.position.y = 1.0
	add_child(cs)
	_set_visible(false)


func _build_visual() -> void:
	_vis = Node3D.new()
	add_child(_vis)
	var skin := Props.color_mat("creature_skin", Color(0.04, 0.04, 0.05), 0.35)
	var body := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.32
	cm.height = 1.9
	body.mesh = cm
	body.material_override = skin
	body.position.y = 1.05
	_vis.add_child(body)
	var head := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.24
	sm.height = 0.5
	head.mesh = sm
	head.material_override = skin
	head.position = Vector3(0, 2.15, -0.05)
	_vis.add_child(head)
	for side in [-1.0, 1.0]:
		var arm := MeshInstance3D.new()
		var am := CylinderMesh.new()
		am.top_radius = 0.06
		am.bottom_radius = 0.04
		am.height = 1.5
		arm.mesh = am
		arm.material_override = skin
		arm.position = Vector3(side * 0.42, 1.1, -0.15)
		arm.rotation.z = side * 0.12
		_vis.add_child(arm)
		var eye := MeshInstance3D.new()
		var em := SphereMesh.new()
		em.radius = 0.04
		em.height = 0.08
		eye.mesh = em
		eye.material_override = Props.color_mat("creature_eye", Color(1, 0.05, 0.02), 0.3, 4.0)
		eye.position = Vector3(side * 0.09, 2.2, -0.26)
		_vis.add_child(eye)
	var glow := OmniLight3D.new()
	glow.light_color = Color(1.0, 0.1, 0.05)
	glow.light_energy = 0.35
	glow.omni_range = 3.5
	glow.position.y = 2.2
	_vis.add_child(glow)


func _set_visible(v: bool) -> void:
	_vis.visible = v
	set_physics_process(true)


# --------------------------------------------------------------------------
# Kurulum
# --------------------------------------------------------------------------

func build_graph() -> void:
	astar.clear()
	var wps := builder.waypoints
	for i in wps.size():
		astar.add_point(i, wps[i])
	var space := get_world_3d().direct_space_state
	for i in wps.size():
		for j in range(i + 1, wps.size()):
			if wps[i].distance_to(wps[j]) <= 13.0 and _clear(space, wps[i], wps[j]):
				astar.connect_points(i, j)
	graph_ready = true


func _clear(space: PhysicsDirectSpaceState3D, a: Vector3, b: Vector3) -> bool:
	var dir := (b - a)
	var perp := dir.cross(Vector3.UP)
	perp = perp.normalized() * 0.35 if perp.length() > 0.01 else Vector3.RIGHT * 0.35
	for off in [-1.0, 0.0, 1.0]:
		var q := PhysicsRayQueryParameters3D.create(a + perp * off + Vector3.UP * 0.9,
			b + perp * off + Vector3.UP * 0.9, 1)
		if not space.intersect_ray(q).is_empty():
			return false
	return true


func activate(spawn_pos: Vector3) -> void:
	active = true
	_spawn(spawn_pos)


func deactivate() -> void:
	active = false
	_to_dormant(0.0)


func _spawn(pos: Vector3) -> void:
	global_position = pos
	velocity = Vector3.ZERO
	_set_visible(true)
	_set_state(State.PATROL)
	_pick_patrol()


func _to_dormant(lull: float) -> void:
	_set_visible(false)
	global_position = Vector3(0, -50, 0)
	velocity = Vector3.ZERO
	_lull_t = lull
	_set_state(State.DORMANT)


func _set_state(s: State) -> void:
	if state == s:
		return
	state = s
	state_changed.emit(int(s))


func alert(pos: Vector3) -> void:
	if not active:
		return
	_investigate_pos = pos
	_set_state(State.INVESTIGATE)
	_wait_t = 0.0
	_set_goal(pos)


## Kamera sahnesi için: yapay zekâsız, sadece görünür figür.
func show_static(pos: Vector3, yaw: float) -> void:
	global_position = pos
	rotation.y = yaw
	_vis.visible = true


func hide_static() -> void:
	if not active:
		_vis.visible = false
		global_position = Vector3(0, -50, 0)


func is_visible_now() -> bool:
	return _vis.visible


func distance_to_player() -> float:
	if not _vis.visible or player == null:
		return 999.0
	return global_position.distance_to(player.global_position)


# --------------------------------------------------------------------------
# Algı
# --------------------------------------------------------------------------

func hear(pos: Vector3, radius: float) -> void:
	if not active or state == State.DORMANT or state == State.CHASE:
		return
	if global_position.distance_to(pos) <= radius:
		_investigate_pos = pos
		_set_state(State.INVESTIGATE)
		_wait_t = 0.0
		_set_goal(pos)


func on_player_hide_changed(hiding: bool) -> void:
	if hiding and state == State.CHASE and Time.get_ticks_msec() / 1000.0 - _last_seen_time < 1.2 \
			and distance_to_player() < 12.0:
		_known_spot = player.hiding_in


func _can_see_player() -> bool:
	if player == null or player.is_hidden() or player.dead:
		return false
	var eye := global_position + Vector3(0, 1.7, 0)
	var tgt := player.head_position()
	var to := tgt - eye
	var dist := to.length()
	var rng_ := 18.0 if player.flashlight_on else 9.0
	if player.crouching:
		rng_ *= 0.6
	if state == State.CHASE:
		rng_ *= 1.4
	if dist > rng_:
		return false
	var fwd := -global_transform.basis.z
	if dist > 3.0 and fwd.dot(to.normalized()) < cos(deg_to_rad(65.0)):
		return false
	var q := PhysicsRayQueryParameters3D.create(eye, tgt, 1 | 2)
	return get_world_3d().direct_space_state.intersect_ray(q).is_empty()


# --------------------------------------------------------------------------
# Yol bulma
# --------------------------------------------------------------------------

func _nearest_wp(pos: Vector3) -> int:
	var space := get_world_3d().direct_space_state
	var best := -1
	var best_d := INF
	var best_any := -1
	var best_any_d := INF
	for i in builder.waypoints.size():
		var d := pos.distance_to(builder.waypoints[i])
		if d < best_any_d:
			best_any_d = d
			best_any = i
		if d < best_d and d < 14.0 and _clear(space, pos, builder.waypoints[i]):
			best_d = d
			best = i
	return best if best != -1 else best_any


func _set_goal(pos: Vector3) -> void:
	_path.clear()
	_path_i = 0
	if not graph_ready:
		_path.append(pos)
		return
	var s := _nearest_wp(global_position)
	var e := _nearest_wp(pos)
	if s == -1 or e == -1:
		_path.append(pos)
		return
	for p in astar.get_point_path(s, e):
		_path.append(p)
	_path.append(pos)


func _follow_path(speed: float, delta: float) -> bool:
	## Hedefe ulaştıysa true döner.
	if _path_i >= _path.size():
		return true
	var target := _path[_path_i]
	var flat := Vector3(target.x - global_position.x, 0.0, target.z - global_position.z)
	var thresh := 0.7 if _path_i < _path.size() - 1 else 0.9
	if flat.length() < thresh and absf(target.y - global_position.y) < 2.5:
		_path_i += 1
		return _path_i >= _path.size()
	_steer(flat.normalized(), speed, delta)
	return false


func _steer(dir: Vector3, speed: float, delta: float) -> void:
	velocity.x = move_toward(velocity.x, dir.x * speed, 18.0 * delta)
	velocity.z = move_toward(velocity.z, dir.z * speed, 18.0 * delta)
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()
	if dir.length() > 0.01:
		var yaw := atan2(-dir.x, -dir.z)
		rotation.y = lerp_angle(rotation.y, yaw, minf(1.0, delta * 8.0))
	_step_dist += Vector2(velocity.x, velocity.z).length() * delta
	if _step_dist > (1.2 if speed > 3.5 else 1.9):
		_step_dist = 0.0
		_steps.pitch_scale = randf_range(0.6, 0.8)
		_steps.play()


func _pick_patrol() -> void:
	var ids: Array[int] = []
	for i in builder.waypoints.size():
		var w := builder.waypoints[i]
		var underground := w.y < -0.5 or w.z > 25.5
		var outdoors := (w.x < 0.5 or w.z < 0.5) and not underground
		if underground and not allow_underground:
			continue
		if outdoors and not allow_outdoors:
			continue
		if w.distance_to(global_position) > 7.0:
			ids.append(i)
	if ids.is_empty():
		return
	var pick: int = ids[randi() % ids.size()]
	if randf() < 0.25 and player != null:
		# Merak: oyuncunun bulunduğu bölgeye yakın bir noktaya yönel (ama oyuncuyu bilmeden).
		var best_d := INF
		for i in ids:
			var d := builder.waypoints[i].distance_to(player.global_position)
			if d < best_d:
				best_d = d
				pick = i
	_set_goal(builder.waypoints[pick])
	_wait_t = 0.0


# --------------------------------------------------------------------------
# Ana döngü
# --------------------------------------------------------------------------

func _physics_process(delta: float) -> void:
	if player == null or builder == null:
		return
	if state == State.DORMANT:
		if active and _lull_t > 0.0:
			_lull_t -= delta
			if _lull_t <= 0.0:
				_respawn_far()
		return

	_door_t -= delta
	if _door_t <= 0.0:
		_door_t = 0.2
		_open_nearby_doors()

	_perceive_t -= delta
	if _perceive_t <= 0.0:
		_perceive_t = 0.12
		if _can_see_player():
			_last_known = player.global_position
			_last_seen_time = Time.get_ticks_msec() / 1000.0
			_lost_t = 0.0
			if state != State.CHASE:
				_begin_chase()

	_growl_t -= delta
	if state == State.CHASE and _growl_t <= 0.0:
		_growl_t = randf_range(3.0, 6.0)
		_growl()

	match state:
		State.PATROL: _tick_patrol(delta)
		State.INVESTIGATE: _tick_investigate(delta)
		State.CHASE: _tick_chase(delta)
		State.SEARCH: _tick_search(delta)

	# Yakalama
	if not player.dead and not player.is_hidden() and state == State.CHASE:
		var d := Vector2(global_position.x - player.global_position.x,
			global_position.z - player.global_position.z).length()
		if d < 1.3 and absf(global_position.y - player.global_position.y) < 2.0:
			_kill()


func _begin_chase() -> void:
	_set_state(State.CHASE)
	_known_spot = null
	_repath_t = 0.0
	_growl_t = 0.0


func _growl() -> void:
	_voice.stream = AudioManager.get_stream(&"growl")
	_voice.pitch_scale = randf_range(0.85, 1.1)
	_voice.volume_db = 6.0
	_voice.play()


func _kill() -> void:
	if player.dead:
		return
	caught.emit()


func _tick_patrol(delta: float) -> void:
	if _follow_path(PATROL_SPEED, delta):
		_wait_t += delta
		velocity.x = move_toward(velocity.x, 0.0, 10.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 10.0 * delta)
		if _wait_t > randf_range(2.5, 5.5):
			_pick_patrol()


func _tick_investigate(delta: float) -> void:
	if _follow_path(INVESTIGATE_SPEED, delta):
		_wait_t += delta
		if _wait_t > 3.0:
			_last_known = _investigate_pos
			_begin_search()


func _tick_chase(delta: float) -> void:
	var speed := chase_speed + (0.5 if rage else 0.0)
	var to_p := player.global_position - global_position
	_repath_t -= delta
	if _lost_t == 0.0 and Time.get_ticks_msec() / 1000.0 - _last_seen_time < 0.4:
		# Oyuncuyu görüyor.
		if to_p.length() < 6.0 and _clear(get_world_3d().direct_space_state, global_position, player.global_position):
			var flat := Vector3(to_p.x, 0.0, to_p.z).normalized()
			_steer(flat, speed, delta)
			return
		if _repath_t <= 0.0:
			_repath_t = 0.4
			_set_goal(player.global_position)
		_follow_path(speed, delta)
		return
	# Görüş kaybı
	_lost_t += delta
	if _known_spot != null:
		_set_goal(_known_spot.exit_position)
		_known_spot = null
	if _follow_path(speed, delta) or _lost_t > 5.0:
		_begin_search()
	if _lost_t == 0.0:
		_lost_t = 0.001


func _begin_search() -> void:
	_set_state(State.SEARCH)
	_search_spots.clear()
	var all: Array[HidingSpot] = []
	for n in get_tree().get_nodes_in_group("hiding_spots"):
		var h := n as HidingSpot
		if h != null and h.global_position.distance_to(_last_known) < 16.0:
			all.append(h)
	all.sort_custom(func(a: HidingSpot, b: HidingSpot) -> bool:
		return a.global_position.distance_to(_last_known) < b.global_position.distance_to(_last_known))
	for i in mini(3, all.size()):
		_search_spots.append(all[i])
	_search_t = 22.0
	_wait_t = 0.0
	_set_goal(_last_known)


func _tick_search(delta: float) -> void:
	_search_t -= delta
	if _search_t <= 0.0:
		_end_search()
		return
	if _follow_path(SEARCH_SPEED, delta):
		_wait_t += delta
		if _wait_t < 1.5:
			return
		_wait_t = 0.0
		if not _search_spots.is_empty():
			var spot: HidingSpot = _search_spots.pop_front()
			_set_goal(spot.exit_position if spot.exit_position != Vector3.ZERO else spot.global_position)
			_check_spot_after_arrival(spot)
		else:
			_end_search()


var _pending_spot: HidingSpot = null


func _check_spot_after_arrival(spot: HidingSpot) -> void:
	_pending_spot = spot


func _end_search() -> void:
	_pending_spot = null
	if rage:
		_set_state(State.PATROL)
		_pick_patrol()
		return
	# Uzun kovalama sonrası yaratık bir süre kaybolur: gerilim ve belirsizlik.
	if randf() < 0.7:
		_to_dormant(randf_range(25.0, 45.0))
	else:
		_set_state(State.PATROL)
		_pick_patrol()


func _process(_delta: float) -> void:
	# Arama sırasında hedef saklanma noktasına varıldığında kontrol et.
	if state == State.SEARCH and _pending_spot != null:
		var target := _pending_spot.exit_position if _pending_spot.exit_position != Vector3.ZERO else _pending_spot.global_position
		if global_position.distance_to(target) < 1.4:
			var spot := _pending_spot
			_pending_spot = null
			if player != null and player.hiding_in == spot and not player.dead:
				if randf() < 0.45:
					_growl()
					_kill()
				else:
					_voice.stream = AudioManager.get_stream(&"growl")
					_voice.pitch_scale = 0.6
					_voice.volume_db = -2.0
					_voice.play()


func _respawn_far() -> void:
	var best := -1
	var best_d := 0.0
	for i in builder.waypoints.size():
		var w := builder.waypoints[i]
		var underground := w.y < -0.5 or w.z > 25.5
		var outdoors := (w.x < 0.5 or w.z < 0.5) and not underground
		if (underground and not allow_underground) or (outdoors and not allow_outdoors):
			continue
		var d := w.distance_to(player.global_position)
		if d > 22.0 and d > best_d * 0.0 and randf() < 0.3:
			best = i
			break
		if d > best_d:
			best_d = d
			best = i
	if best == -1:
		_lull_t = 5.0
		return
	_spawn(builder.waypoints[best])


func _open_nearby_doors() -> void:
	for n in get_tree().get_nodes_in_group("doors"):
		var d := n as Door
		if d == null or d.is_open:
			continue
		var center := d.global_position + d.global_transform.basis.x * d.width * 0.5
		if center.distance_to(global_position) < 1.8 and absf(center.y - global_position.y) < 3.0:
			d.force_open(true)
