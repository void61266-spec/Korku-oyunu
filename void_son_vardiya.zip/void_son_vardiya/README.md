# VOID: SON VARDİYA

Godot 4.3 (GDScript, GL Compatibility) ile yazılmış mobil 3D korku / hayatta kalma oyunu.
Tüm 3D dünya, materyaller ve sesler kodla üretilir; harici asset gerektirmez.

## Durum

| Sistem | Durum |
|---|---|
| Ana menü (3D arka plan, Tek/Çok oyunculu, Ayarlar, Çıkış) | Hazır |
| 3D market + bodrum + laboratuvar + dış alan | Hazır |
| Oyuncu: yürü / koş / eğil / fener / etkileşim / saklanma | Hazır |
| Dokunmatik kontroller (joystick, bakış, butonlar) | Hazır |
| Envanter, fener pili, görev sistemi (18 adım) | Hazır |
| Yaratık AI (devriye, ses/görüş, kovalama, arama, kaybetme) | Hazır |
| Hikâye (kesinti, kameralar, gizli geçit, final) | Hazır |
| Kayıt sistemi, Ayarlar, prosedürel ses | Hazır |
| Çok oyunculu (ENet host/client + oda kodu) | **Henüz yok** (menüde pasif) |
| İmzalı APK | Aşağıdaki betikle üretilir |

## Çalıştırma (PC, test)
Godot 4.3 ile `project.godot` dosyasını aç. WASD, fare, E (etkileşim), F (fener), C (eğil), Shift (koş), I (envanter).
Dokunmatik arayüzü PC'de görmek için `VOID_TOUCH=1` ortam değişkeni.

## Test
`godot --headless --path . res://tests/smoke.tscn` → hikâyenin tamamını otomatik oynatır (yol grafı, görevler, kayıt, yaratık).

## APK
1. Godot 4.3 + export şablonları, JDK 17+, Android SDK (`platforms;android-34`, `build-tools;34.0.0`, `platform-tools`, `cmdline-tools;latest`).
2. `export ANDROID_HOME=...; export GODOT=/yol/godot`
3. `./scripts_build/build_android.sh debug` → `build/void_son_vardiya_debug.apk`
4. Release: `RELEASE_KEYSTORE=... RELEASE_KEYSTORE_USER=... RELEASE_KEYSTORE_PASSWORD=... ./scripts_build/build_android.sh release`
5. GitHub'a yüklersen `.github/workflows/android.yml` APK'yı otomatik üretir (Actions → Artifacts).

Min SDK 21, Target SDK 34 (Godot 4.3 şablonu), arm64 + armv7. İzinler: VIBRATE, INTERNET, ACCESS_NETWORK_STATE.

## Klasörler
`scripts/autoload` (Settings, GameManager, SaveSystem, AudioManager) · `scripts/player` · `scripts/game` (yaratık, görev, yönetmen) · `scripts/world` (harita, kapı, eşya) · `scripts/inventory` · `scripts/ui` · `tests`
